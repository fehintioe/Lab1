document.addEventListener('DOMContentLoaded', function() {
    alert('Welcome to my Boilerplate page!');
});
